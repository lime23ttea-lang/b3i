# ibeTube

Plataforma de visualización de videos limpia, segura y sin distracciones.

## 🎯 Concepto

ibeTube es un "video viewer" minimalista que proporciona una experiencia de visualización de YouTube limpia y controlada, sin distracciones, comentarios ni recomendaciones invasivas.

## ✨ Características (V1)

- ✅ **Búsqueda de videos** sin necesidad de API key
- ✅ **Reproductor limpio** con interfaz minimalista
- ✅ **Detección de URLs** de YouTube (youtube.com, youtu.be, shorts, embed)
- ✅ **Validación de video IDs**
- ✅ **Sistema de filtros** (STRICT, SAFE, EDUCATIONAL, GENERAL)
- ✅ **Blocklist** para contenido bloqueado
- ✅ **Sistema de reportes** con múltiples motivos
- ✅ **Múltiples servidores** con fallback automático
- ✅ **Diseño responsive** (mobile, tablet, desktop)
- ✅ **Dark mode** por defecto
- ✅ **Arquitectura modular** preparada para expansiones

## 🚀 Instalación

```bash
# Clonar repositorio
git clone https://github.com/TU-USUARIO/ibetube.git
cd ibetube

# Instalar dependencias
npm install

# Iniciar servidor de desarrollo
npm run dev

# Compilar para producción
npm run build
```

## 🛠️ Tecnologías

- **React 18** - Framework de UI
- **TypeScript** - Tipado estático
- **Vite** - Build tool
- **Tailwind CSS 4** - Estilos
- **React Router** - Navegación
- **Lucide React** - Iconos
- **Piped API** - Búsqueda de videos (open-source, sin API key)

## 📁 Estructura del Proyecto

```
src/
├── App.tsx              # Router principal
├── main.tsx             # Entry point
├── index.css            # Estilos globales
├── types/
│   └── index.ts         # Tipos TypeScript
├── utils/
│   └── youtube.ts       # Utilidades YouTube
├── services/
│   └── search.ts        # Servicio de búsqueda (Piped API)
├── components/
│   ├── Header.tsx       # Cabecera
│   ├── SearchBar.tsx    # Barra de búsqueda
│   ├── VideoCard.tsx    # Tarjeta de video
│   └── VideoPlayer.tsx  # Reproductor
└── pages/
    ├── Home.tsx         # Página principal
    ├── Watch.tsx        # Página de reproducción
    └── Search.tsx       # Página de resultados
```

## 🎮 Uso

### Búsqueda de videos
1. Escribe un término en el buscador
2. Selecciona el modo de filtrado (STRICT, SAFE, EDUCATIONAL, GENERAL)
3. Los resultados se muestran en tarjetas

### Acceso directo por URL
1. Pega una URL de YouTube en el campo de búsqueda
2. Formatos soportados:
   - `youtube.com/watch?v=VIDEO_ID`
   - `youtu.be/VIDEO_ID`
   - `youtube.com/shorts/VIDEO_ID`
   - `youtube.com/embed/VIDEO_ID`
3. También puedes pegar directamente el video ID (11 caracteres)

### Reportar contenido
1. En la página de reproducción, haz clic en "Reportar"
2. Selecciona el motivo del reporte
3. El reporte se guarda localmente para revisión

## 🔒 Privacidad

- No se recopilan datos personales innecesarios
- Los reportes y blocklist se guardan localmente (localStorage)
- No se almacenan contraseñas en texto plano
- No se exponen claves privadas en el frontend

## 🗺️ Roadmap

- [ ] V2: URL directa mejorada + validación avanzada
- [ ] V3: SafeSearch + filtros avanzados
- [ ] V4: Blocklist + reportes mejorados
- [ ] V5: Cuentas + historial + favoritos
- [ ] V6: Modo Education
- [ ] V7: Moderación avanzada
- [ ] V8: Admin Panel
- [ ] V9: Múltiples servidores + fallback mejorado
- [ ] V10: Extensión de navegador
- [ ] V11: PWA + móvil
- [ ] V12: Optimización avanzada

## 📄 Licencia

Este proyecto es de código abierto.

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Por favor, abre un issue primero para discutir los cambios propuestos.

## ⚠️ Nota Legal

Este proyecto utiliza APIs oficiales y métodos compatibles con las políticas de YouTube. No almacena ni distribuye contenido protegido por derechos de autor.

---

**Desarrollado con ❤️ para una experiencia de video más limpia y segura**

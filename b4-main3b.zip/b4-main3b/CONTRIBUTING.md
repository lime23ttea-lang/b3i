# Guía de Contribución

¡Gracias por tu interés en contribuir a ibeTube! 🎉

## 🚀 Cómo Contribuir

### 1. Reportar Bugs

Si encuentras un bug, por favor abre un issue con la siguiente información:

- Descripción clara del problema
- Pasos para reproducirlo
- Comportamiento esperado vs actual
- Capturas de pantalla (si aplica)
- Navegador y versión
- Sistema operativo

### 2. Sugerir Mejoras

Las sugerencias son bienvenidas. Abre un issue con:

- Descripción de la mejora propuesta
- Casos de uso
- Ejemplos de implementación (si tienes ideas)

### 3. Enviar Pull Requests

#### Proceso:

1. **Fork** el repositorio
2. **Clona** tu fork:
   ```bash
   git clone https://github.com/TU-USUARIO/ibetube.git
   cd ibetube
   ```

3. **Crea una rama** para tu feature:
   ```bash
   git checkout -b feature/nombre-de-tu-feature
   ```

4. **Instala dependencias**:
   ```bash
   npm install
   ```

5. **Haz tus cambios** y asegúrate de:
   - Seguir el estilo de código existente
   - Escribir código TypeScript tipado
   - Mantener la arquitectura modular
   - Probar tus cambios localmente

6. **Commit tus cambios**:
   ```bash
   git commit -m "feat: descripción clara del cambio"
   ```
   
   Usamos conventional commits:
   - `feat:` nueva funcionalidad
   - `fix:` corrección de bug
   - `docs:` cambios en documentación
   - `style:` cambios de formato (sin afectar código)
   - `refactor:` refactorización de código
   - `test:` agregar o modificar tests
   - `chore:` tareas de mantenimiento

7. **Push** a tu fork:
   ```bash
   git push origin feature/nombre-de-tu-feature
   ```

8. **Abre un Pull Request** en GitHub

## 💻 Desarrollo Local

### Requisitos

- Node.js 18+ 
- npm o yarn

### Comandos

```bash
# Instalar dependencias
npm install

# Servidor de desarrollo
npm run dev

# Compilar para producción
npm run build

# Verificar tipos TypeScript
npm run typecheck
```

## 📋 Estándares de Código

### TypeScript

- Usa tipos explícitos cuando sea posible
- Evita `any`
- Define interfaces en `src/types/`
- Usa enums para valores constantes

### React

- Componentes funcionales con hooks
- Props tipadas con TypeScript
- Nombres de componentes en PascalCase
- Archivos de componentes en PascalCase

### CSS/Tailwind

- Usa clases de Tailwind CSS
- Evita CSS personalizado cuando sea posible
- Mantén consistencia en el diseño
- Mobile-first approach

### Estructura de Archivos

```
src/
├── components/     # Componentes reutilizables
├── pages/          # Páginas de la aplicación
├── services/       # Servicios (API, lógica de negocio)
├── utils/          # Funciones utilitarias
└── types/          # Tipos TypeScript
```

## 🎯 Roadmap

Consulta el [README.md](README.md) para ver el roadmap completo. Si quieres trabajar en una feature específica, comenta en el issue correspondiente.

## 🐛 Debugging

Si encuentras problemas:

1. Limpia `node_modules` y reinstala:
   ```bash
   rm -rf node_modules package-lock.json
   npm install
   ```

2. Limpia el caché de Vite:
   ```bash
   rm -rf node_modules/.vite
   ```

3. Verifica que tu Node.js sea versión 18+

## 📝 Licencia

Al contribuir, aceptas que tus contribuciones se licencien bajo la licencia MIT del proyecto.

## 🤝 Código de Conducta

- Sé respetuoso y constructivo
- Acepta críticas de manera positiva
- Enfócate en lo que es mejor para la comunidad
- Muestra empatía hacia otros participantes

---

¡Gracias por ayudar a hacer ibetube mejor! 🚀

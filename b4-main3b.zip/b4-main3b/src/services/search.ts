// ============================================================
// ibeTube - Servicio de búsqueda
// Usa Piped API (open-source, sin API key requerida)
// Preparado para múltiples servidores (fallback)
// ============================================================

import type { VideoInfo, FilterMode } from '../types';

// Servidores Piped API disponibles (balanceo de carga / redundancia)
const PipedServers = [
  'https://pipedapi.kavin.rocks',
  'https://pipedapi.adminforge.de',
  'https://api.piped.projectsegfau.lt',
  'https://pipedapi.in.projectsegfau.lt',
];

let currentServerIndex = 0;

function getCurrentServer(): string {
  return PipedServers[currentServerIndex];
}

function rotateServer(): void {
  currentServerIndex = (currentServerIndex + 1) % PipedServers.length;
}

/**
 * Mapea el filtro de ibeTube al filtro de Piped
 */
function getSearchFilter(filterMode: FilterMode): string {
  // Piped soporta: all, videos, channels, playlists, music_songs, music_videos, music_albums, music_playlists
  return 'videos';
}

/**
 * Busca videos usando Piped API
 * Intenta múltiples servidores en caso de fallo
 */
export async function searchVideos(
  query: string,
  filterMode: FilterMode = 'SAFE'
): Promise<VideoInfo[]> {
  const maxAttempts = PipedServers.length;
  let lastError: Error | null = null;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const server = getCurrentServer();
    
    try {
      const params = new URLSearchParams({
        q: query,
        filter: getSearchFilter(filterMode),
      });

      const response = await fetch(`${server}/search?${params}`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Server responded with ${response.status}`);
      }

      const data = await response.json();
      
      // Filtrar resultados (Piped devuelve streams, channels, etc.)
      const videos: VideoInfo[] = (data.items || [])
        .filter((item: any) => item.type === 'stream' && item.url)
        .map((item: any) => ({
          id: extractIdFromUrl(item.url) || item.url?.replace('/watch?v=', ''),
          title: item.title || 'Sin título',
          channel: item.uploaderName || 'Desconocido',
          channelId: item.uploaderUrl?.replace('/channel/', '') || '',
          thumbnail: item.thumbnail || '',
          duration: formatDuration(item.duration || 0),
          publishedAt: item.uploadedDate || '',
        }))
        .filter((v: VideoInfo) => v.id && v.id.length === 11);

      return videos;
    } catch (error) {
      lastError = error as Error;
      rotateServer();
      continue;
    }
  }

  throw lastError || new Error('Todos los servidores no están disponibles');
}

/**
 * Obtiene información de un video específico
 */
export async function getVideoInfo(videoId: string): Promise<VideoInfo | null> {
  const maxAttempts = PipedServers.length;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const server = getCurrentServer();

    try {
      const response = await fetch(`${server}/streams/${videoId}`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Server responded with ${response.status}`);
      }

      const data = await response.json();

      return {
        id: videoId,
        title: data.title || 'Sin título',
        channel: data.uploader || 'Desconocido',
        channelId: data.uploaderUrl?.replace('/channel/', '') || '',
        thumbnail: data.thumbnailUrl || '',
        duration: formatDuration(data.duration || 0),
        publishedAt: data.uploadDate || '',
        description: data.description || '',
      };
    } catch (error) {
      rotateServer();
      continue;
    }
  }

  return null;
}

/**
 * Extrae el video ID de una URL de Piped (/watch?v=ID)
 */
function extractIdFromUrl(url: string): string | null {
  if (!url) return null;
  const match = url.match(/\/watch\?v=([a-zA-Z0-9_-]{11})/);
  return match ? match[1] : null;
}

/**
 * Formatea duración en segundos a formato legible
 */
function formatDuration(seconds: number): string {
  if (!seconds || seconds < 0) return '';
  
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;

  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${secs.toString().padStart(2, '0')}`;
}

/**
 * Obtiene el estado de los servidores
 */
export async function getServerStatus(): Promise<{ name: string; url: string; online: boolean }[]> {
  const results = await Promise.allSettled(
    PipedServers.map(async (server) => {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);

      try {
        const response = await fetch(`${server}/healthcheck`, {
          signal: controller.signal,
        });
        clearTimeout(timeout);
        return { name: new URL(server).hostname, url: server, online: response.ok };
      } catch {
        clearTimeout(timeout);
        return { name: new URL(server).hostname, url: server, online: false };
      }
    })
  );

  return results.map((result, index) => {
    if (result.status === 'fulfilled') return result.value;
    return { name: new URL(PipedServers[index]).hostname, url: PipedServers[index], online: false };
  });
}

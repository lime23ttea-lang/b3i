// ============================================================
// ibeTube - Tipos TypeScript
// Arquitectura preparada para versiones futuras
// ============================================================

// --- Video ---
export interface VideoInfo {
  id: string;
  title: string;
  channel: string;
  channelId: string;
  thumbnail: string;
  duration?: string;
  publishedAt?: string;
  description?: string;
  category?: string;
}

// --- Filtros ---
export type FilterMode = 'SAFE' | 'EDUCATIONAL' | 'GENERAL' | 'STRICT';

// --- Reportes ---
export type ReportReason =
  | 'inappropriate'
  | 'dangerous'
  | 'sexual'
  | 'violence'
  | 'spam'
  | 'misleading'
  | 'other';

export type ContentStatus = 'NORMAL' | 'FLAGGED' | 'UNDER_REVIEW' | 'BLOCKED';

export interface Report {
  id: string;
  videoId: string;
  reason: ReportReason;
  description?: string;
  reportedBy: string;
  status: ContentStatus;
  createdAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
}

// --- Blocklist ---
export interface BlocklistEntry {
  videoId: string;
  reason: string;
  reportedBy: string;
  status: ContentStatus;
  createdAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
}

// --- Canales bloqueados ---
export interface BlockedChannel {
  channelId: string;
  reason: string;
  status: ContentStatus;
  createdAt: string;
  reviewedAt?: string;
}

// --- Historial ---
export interface HistoryEntry {
  videoId: string;
  title: string;
  thumbnail: string;
  channel: string;
  watchedAt: string;
  progress?: number;
}

// --- Favoritos ---
export interface FavoriteEntry {
  videoId: string;
  title: string;
  thumbnail: string;
  channel: string;
  addedAt: string;
  list: 'favorites' | 'watch-later';
}

// --- Usuarios ---
export type UserRole = 'USER' | 'MODERATOR' | 'ADMIN';

export interface User {
  id: string;
  username: string;
  email: string;
  role: UserRole;
  createdAt: string;
}

// --- Servidores ---
export type ServerStatus = 'online' | 'offline' | 'maintenance';

export interface Server {
  id: string;
  name: string;
  url: string;
  status: ServerStatus;
  latency?: number;
}

// --- Configuración ---
export interface AppSettings {
  filterMode: FilterMode;
  educationMode: boolean;
  historyEnabled: boolean;
  activeServer: string;
}

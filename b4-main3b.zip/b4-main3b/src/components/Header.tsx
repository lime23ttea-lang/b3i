import { Link } from 'react-router-dom';
import { Play, Shield } from 'lucide-react';

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-[#0a0a0f]/80 backdrop-blur-xl border-b border-[#1a1a2e]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="relative">
              <div className="w-9 h-9 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20 group-hover:shadow-indigo-500/40 transition-shadow duration-300">
                <Play className="w-4 h-4 text-white fill-white ml-0.5" />
              </div>
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
              ibeTube
            </span>
          </Link>

          {/* Nav */}
          <nav className="flex items-center gap-3">
            <Link
              to="/"
              className="text-sm text-slate-400 hover:text-white transition-colors px-3 py-2 rounded-lg hover:bg-[#1a1a2e]"
            >
              Inicio
            </Link>
            <div className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-xs font-medium text-emerald-400">Safe</span>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
}

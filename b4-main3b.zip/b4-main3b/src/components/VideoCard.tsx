import { Link } from 'react-router-dom';
import type { VideoInfo } from '../types';

interface VideoCardProps {
  video: VideoInfo;
}

export default function VideoCard({ video }: VideoCardProps) {
  return (
    <Link
      to={`/watch/${video.id}`}
      className="group block rounded-xl overflow-hidden bg-[#12121f] border border-[#1e1e35] hover:border-indigo-500/30 transition-all duration-300 hover:shadow-lg hover:shadow-indigo-500/5"
    >
      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden">
        <img
          src={video.thumbnail}
          alt={video.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
          onError={(e) => {
            (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${video.id}/hqdefault.jpg`;
          }}
        />
        {video.duration && (
          <span className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-0.5 rounded font-mono">
            {video.duration}
          </span>
        )}
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>

      {/* Info */}
      <div className="p-3">
        <h3 className="text-sm font-medium text-white line-clamp-2 leading-snug group-hover:text-indigo-300 transition-colors">
          {video.title}
        </h3>
        <p className="text-xs text-slate-400 mt-1.5 truncate">
          {video.channel}
        </p>
        {video.publishedAt && (
          <p className="text-xs text-slate-500 mt-1">
            {video.publishedAt}
          </p>
        )}
      </div>
    </Link>
  );
}

import { useState, useRef, useEffect } from 'react';
import { Search, X } from 'lucide-react';

interface SearchBarProps {
  onSearch: (query: string) => void;
  onUrlSubmit: (url: string) => void;
  placeholder?: string;
  initialValue?: string;
  autoFocus?: boolean;
}

export default function SearchBar({
  onSearch,
  onUrlSubmit,
  placeholder = 'Buscar videos o pegar URL de YouTube...',
  initialValue = '',
  autoFocus = false,
}: SearchBarProps) {
  const [value, setValue] = useState(initialValue);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (autoFocus && inputRef.current) {
      inputRef.current.focus();
    }
  }, [autoFocus]);

  useEffect(() => {
    setValue(initialValue);
  }, [initialValue]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = value.trim();
    if (!trimmed) return;

    // Detectar si es una URL de YouTube
    const urlPatterns = [
      /(?:https?:\/\/)?(?:www\.)?youtube\.com\/watch\?.*v=([a-zA-Z0-9_-]{11})/,
      /(?:https?:\/\/)?youtu\.be\/([a-zA-Z0-9_-]{11})/,
      /(?:https?:\/\/)?(?:www\.)?youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
      /(?:https?:\/\/)?(?:www\.)?youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    ];

    for (const pattern of urlPatterns) {
      const match = trimmed.match(pattern);
      if (match && match[1]) {
        onUrlSubmit(trimmed);
        return;
      }
    }

    // Si es un ID de 11 caracteres válido
    if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
      onUrlSubmit(trimmed);
      return;
    }

    // Si no es URL, es una búsqueda
    onSearch(trimmed);
  };

  const handleClear = () => {
    setValue('');
    inputRef.current?.focus();
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl mx-auto">
      <div className="relative group">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/20 to-purple-500/20 rounded-2xl blur-xl opacity-0 group-focus-within:opacity-100 transition-opacity duration-500" />
        <div className="relative flex items-center bg-[#1a1a2e] border border-[#2a2a4a] rounded-2xl overflow-hidden transition-all duration-300 group-focus-within:border-indigo-500/50 group-focus-within:shadow-lg group-focus-within:shadow-indigo-500/10">
          <Search className="w-5 h-5 text-slate-400 ml-4 flex-shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={placeholder}
            className="flex-1 bg-transparent text-white placeholder-slate-500 px-4 py-4 text-base outline-none"
            autoComplete="off"
            spellCheck={false}
          />
          {value && (
            <button
              type="button"
              onClick={handleClear}
              className="p-2 mr-1 text-slate-400 hover:text-white transition-colors"
              aria-label="Limpiar"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            type="submit"
            className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-4 font-medium transition-colors duration-200 flex-shrink-0"
          >
            Buscar
          </button>
        </div>
      </div>
    </form>
  );
}

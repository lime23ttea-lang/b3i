import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import SearchBar from '../components/SearchBar';
import { FilterMode } from '../types';
import { Shield, BookOpen, Globe, Lock, Sparkles, Link2, Play, Zap } from 'lucide-react';

const FILTER_OPTIONS: { mode: FilterMode; label: string; icon: React.ReactNode; description: string }[] = [
  { mode: 'STRICT', label: 'Strict', icon: <Lock className="w-4 h-4" />, description: 'Máximo filtrado' },
  { mode: 'SAFE', label: 'Safe', icon: <Shield className="w-4 h-4" />, description: 'Contenido seguro' },
  { mode: 'EDUCATIONAL', label: 'Education', icon: <BookOpen className="w-4 h-4" />, description: 'Solo educativo' },
  { mode: 'GENERAL', label: 'General', icon: <Globe className="w-4 h-4" />, description: 'Estándar' },
];

export default function Home() {
  const navigate = useNavigate();
  const [filterMode, setFilterMode] = useState<FilterMode>('SAFE');
  const [urlInput, setUrlInput] = useState('');

  const handleSearch = (query: string) => {
    navigate(`/search?q=${encodeURIComponent(query)}&filter=${filterMode}`);
  };

  const handleUrlSubmit = (input: string) => {
    // Intentar extraer video ID
    const patterns = [
      /(?:https?:\/\/)?(?:www\.)?youtube\.com\/watch\?.*v=([a-zA-Z0-9_-]{11})/,
      /(?:https?:\/\/)?youtu\.be\/([a-zA-Z0-9_-]{11})/,
      /(?:https?:\/\/)?(?:www\.)?youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
      /(?:https?:\/\/)?(?:www\.)?youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    ];

    for (const pattern of patterns) {
      const match = input.match(pattern);
      if (match && match[1]) {
        navigate(`/watch/${match[1]}`);
        return;
      }
    }

    // Si es un ID de 11 caracteres
    if (/^[a-zA-Z0-9_-]{11}$/.test(input.trim())) {
      navigate(`/watch/${input.trim()}`);
      return;
    }

    // Si no se puede extraer, buscar
    handleSearch(input);
  };

  const handleUrlDirect = () => {
    if (urlInput.trim()) {
      handleUrlSubmit(urlInput);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col">
      {/* Hero */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-12 sm:py-20">
        {/* Logo grande */}
        <div className="mb-8 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl shadow-2xl shadow-indigo-500/30 mb-6">
            <Play className="w-9 h-9 text-white fill-white ml-1" />
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-3">
            ibeTube
          </h1>
          <p className="text-slate-400 text-lg max-w-md mx-auto">
            Visualización de videos limpia, segura y sin distracciones
          </p>
        </div>

        {/* Buscador principal */}
        <div className="w-full max-w-2xl mb-8">
          <SearchBar
            onSearch={handleSearch}
            onUrlSubmit={handleUrlSubmit}
            placeholder="Buscar videos o pegar URL de YouTube..."
            autoFocus
          />
        </div>

        {/* Quick actions */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-12">
          <button
            onClick={() => {
              const el = document.getElementById('url-input-section');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="flex items-center gap-2 px-4 py-2.5 bg-[#1a1a2e] border border-[#2a2a4a] rounded-xl text-sm text-slate-300 hover:text-white hover:border-indigo-500/40 transition-all duration-200"
          >
            <Link2 className="w-4 h-4" />
            Pegar URL
          </button>
          <button
            onClick={() => handleSearch('música popular')}
            className="flex items-center gap-2 px-4 py-2.5 bg-[#1a1a2e] border border-[#2a2a4a] rounded-xl text-sm text-slate-300 hover:text-white hover:border-indigo-500/40 transition-all duration-200"
          >
            <Zap className="w-4 h-4" />
            Explorar
          </button>
        </div>

        {/* Filtros */}
        <div className="w-full max-w-xl">
          <p className="text-center text-xs text-slate-500 uppercase tracking-wider mb-4 font-medium">
            Modo de filtrado
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {FILTER_OPTIONS.map((option) => (
              <button
                key={option.mode}
                onClick={() => setFilterMode(option.mode)}
                className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-all duration-200 ${
                  filterMode === option.mode
                    ? 'bg-indigo-500/10 border-indigo-500/50 text-indigo-300 shadow-lg shadow-indigo-500/10'
                    : 'bg-[#12121f] border-[#1e1e35] text-slate-400 hover:border-[#2a2a4a] hover:text-slate-300'
                }`}
              >
                {option.icon}
                <span className="text-xs font-medium">{option.label}</span>
                <span className="text-[10px] opacity-60 hidden sm:block">{option.description}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* URL Section */}
      <div id="url-input-section" className="border-t border-[#1a1a2e] bg-[#08080d]">
        <div className="max-w-3xl mx-auto px-4 py-12">
          <div className="text-center mb-6">
            <Sparkles className="w-5 h-5 text-indigo-400 mx-auto mb-2" />
            <h2 className="text-lg font-semibold text-white">Acceso directo por URL</h2>
            <p className="text-sm text-slate-400 mt-1">
              Pega una URL de YouTube para abrir el video directamente
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 items-center">
            <div className="flex-1 relative w-full">
              <input
                type="text"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="https://www.youtube.com/watch?v=..."
                className="w-full bg-[#1a1a2e] border border-[#2a2a4a] rounded-xl px-4 py-3.5 text-white placeholder-slate-500 outline-none focus:border-indigo-500/50 transition-colors"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleUrlDirect();
                  }
                }}
              />
            </div>
            <button
              onClick={handleUrlDirect}
              className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3.5 rounded-xl font-medium transition-colors whitespace-nowrap"
            >
              Abrir video
            </button>
          </div>
          <p className="text-xs text-slate-500 mt-3 text-center">
            Formatos soportados: youtube.com/watch?v=, youtu.be/, youtube.com/shorts/, youtube.com/embed/
          </p>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-[#1a1a2e] bg-[#0a0a0f] py-6">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-xs text-slate-500">
            ibeTube v1.0 — Video viewer limpio y seguro
          </p>
          <p className="text-xs text-slate-600 mt-1">
            Contenido proporcionado mediante métodos oficiales de YouTube
          </p>
        </div>
      </footer>
    </div>
  );
}

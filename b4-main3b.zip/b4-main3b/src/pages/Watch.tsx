import { useParams, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import VideoPlayer from '../components/VideoPlayer';
import { isValidVideoId } from '../utils/youtube';
import { getVideoInfo } from '../services/search';
import { ArrowLeft, Flag, AlertTriangle, Shield, User, Calendar, Clock } from 'lucide-react';
import type { VideoInfo } from '../types';

export default function Watch() {
  const { videoId } = useParams<{ videoId: string }>();
  const navigate = useNavigate();
  const [isValid, setIsValid] = useState(true);
  const [isBlocked, setIsBlocked] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [reportSubmitted, setReportSubmitted] = useState(false);
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [loadingInfo, setLoadingInfo] = useState(true);

  // Comprobar blocklist y cargar info
  useEffect(() => {
    if (!videoId || !isValidVideoId(videoId)) {
      setIsValid(false);
      setLoadingInfo(false);
      return;
    }

    // Comprobar blocklist
    try {
      const blocklist = JSON.parse(localStorage.getItem('ibetube_blocklist') || '[]');
      const isVideoBlocked = blocklist.some(
        (entry: { videoId: string; status: string }) =>
          entry.videoId === videoId && entry.status === 'BLOCKED'
      );
      setIsBlocked(isVideoBlocked);
    } catch {
      // Si hay error, no bloquear
    }

    // Cargar información del video
    loadVideoInfo(videoId);
  }, [videoId]);

  const loadVideoInfo = async (id: string) => {
    setLoadingInfo(true);
    try {
      const info = await getVideoInfo(id);
      setVideoInfo(info);
    } catch {
      // Si falla, seguimos sin info (el video puede reproducirse igual)
      setVideoInfo(null);
    } finally {
      setLoadingInfo(false);
    }
  };

  if (!videoId || !isValid) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <AlertTriangle className="w-12 h-12 text-amber-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-white mb-2">Video no válido</h2>
          <p className="text-slate-400 mb-6">
            El ID del video no es válido o no se pudo reconocer.
          </p>
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2.5 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Volver al inicio
          </button>
        </div>
      </div>
    );
  }

  if (isBlocked) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <Shield className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-white mb-2">Contenido no disponible</h2>
          <p className="text-slate-400 mb-6">
            Este contenido no está disponible en esta plataforma.
          </p>
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2.5 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Volver al inicio
          </button>
        </div>
      </div>
    );
  }

  const handleReport = () => {
    if (!reportReason) return;

    try {
      const reports = JSON.parse(localStorage.getItem('ibetube_reports') || '[]');
      reports.push({
        id: Date.now().toString(),
        videoId,
        reason: reportReason,
        status: 'FLAGGED',
        reportedBy: 'anonymous',
        createdAt: new Date().toISOString(),
      });
      localStorage.setItem('ibetube_reports', JSON.stringify(reports));
    } catch {
      // Silent fail
    }

    setReportSubmitted(true);
    setTimeout(() => {
      setShowReport(false);
      setReportSubmitted(false);
      setReportReason('');
    }, 2000);
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-[#0a0a0f]">
      <div className="max-w-5xl mx-auto px-4 py-6">
        {/* Back button */}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-4 text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          Volver
        </button>

        {/* Player */}
        <VideoPlayer videoId={videoId} title={videoInfo?.title || 'Video'} />

        {/* Info */}
        <div className="mt-5">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
            <div className="flex-1">
              {loadingInfo ? (
                <div className="h-7 w-3/4 bg-[#1a1a2e] rounded animate-pulse" />
              ) : (
                <h1 className="text-lg sm:text-xl font-semibold text-white leading-snug">
                  {videoInfo?.title || `Video — ${videoId}`}
                </h1>
              )}
              
              <div className="flex flex-wrap items-center gap-3 mt-2 text-sm text-slate-400">
                {videoInfo?.channel && (
                  <>
                    <span className="flex items-center gap-1">
                      <User className="w-3.5 h-3.5" />
                      {videoInfo.channel}
                    </span>
                    <span>•</span>
                  </>
                )}
                {videoInfo?.publishedAt && (
                  <>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {videoInfo.publishedAt}
                    </span>
                    <span>•</span>
                  </>
                )}
                {videoInfo?.duration && (
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {videoInfo.duration}
                  </span>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowReport(!showReport)}
                className="flex items-center gap-1.5 px-3 py-2 text-sm text-slate-400 hover:text-red-400 bg-[#12121f] border border-[#1e1e35] rounded-lg hover:border-red-500/30 transition-all"
              >
                <Flag className="w-3.5 h-3.5" />
                Reportar
              </button>
            </div>
          </div>

          {/* Report form */}
          {showReport && (
            <div className="mt-4 p-4 bg-[#12121f] border border-[#1e1e35] rounded-xl">
              {reportSubmitted ? (
                <div className="flex items-center gap-2 text-emerald-400">
                  <Shield className="w-5 h-5" />
                  <span className="text-sm font-medium">Reporte enviado correctamente</span>
                </div>
              ) : (
                <>
                  <p className="text-sm text-slate-300 mb-3 font-medium">Motivo del reporte:</p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-4">
                    {[
                      { value: 'inappropriate', label: 'Contenido inapropiado' },
                      { value: 'dangerous', label: 'Contenido peligroso' },
                      { value: 'sexual', label: 'Contenido sexual' },
                      { value: 'violence', label: 'Violencia' },
                      { value: 'spam', label: 'Spam' },
                      { value: 'misleading', label: 'Información engañosa' },
                    ].map((reason) => (
                      <button
                        key={reason.value}
                        onClick={() => setReportReason(reason.value)}
                        className={`text-xs px-3 py-2 rounded-lg border transition-all ${
                          reportReason === reason.value
                            ? 'bg-red-500/10 border-red-500/40 text-red-300'
                            : 'bg-[#1a1a2e] border-[#2a2a4a] text-slate-400 hover:text-slate-300'
                        }`}
                      >
                        {reason.label}
                      </button>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={handleReport}
                      disabled={!reportReason}
                      className="px-4 py-2 bg-red-600 hover:bg-red-500 disabled:bg-slate-700 disabled:text-slate-500 text-white text-sm rounded-lg transition-colors"
                    >
                      Enviar reporte
                    </button>
                    <button
                      onClick={() => setShowReport(false)}
                      className="px-4 py-2 bg-[#1a1a2e] border border-[#2a2a4a] text-slate-400 text-sm rounded-lg hover:text-white transition-colors"
                    >
                      Cancelar
                    </button>
                  </div>
                </>
              )}
            </div>
          )}

          {/* Description */}
          {videoInfo?.description && (
            <div className="mt-6 p-4 bg-[#12121f] border border-[#1e1e35] rounded-xl">
              <h3 className="text-sm font-medium text-white mb-2">Descripción</h3>
              <p className="text-sm text-slate-400 whitespace-pre-wrap line-clamp-3">
                {videoInfo.description}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

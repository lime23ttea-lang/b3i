import { useSearchParams, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import SearchBar from '../components/SearchBar';
import VideoCard from '../components/VideoCard';
import { extractVideoId } from '../utils/youtube';
import { searchVideos } from '../services/search';
import type { VideoInfo, FilterMode } from '../types';
import { Search, AlertCircle, Wifi, WifiOff } from 'lucide-react';

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const query = searchParams.get('q') || '';
  const filter = (searchParams.get('filter') || 'SAFE') as FilterMode;
  const [results, setResults] = useState<VideoInfo[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentServer, setCurrentServer] = useState<string>('');

  useEffect(() => {
    if (query) {
      performSearch(query, filter);
    }
  }, [query, filter]);

  const performSearch = async (searchQuery: string, filterMode: FilterMode) => {
    setLoading(true);
    setError(null);

    // Primero verificar si es un video ID o URL
    const videoId = extractVideoId(searchQuery);
    if (videoId) {
      navigate(`/watch/${videoId}`);
      return;
    }

    try {
      const videos = await searchVideos(searchQuery, filterMode);
      setResults(videos);
      setCurrentServer('');
    } catch (err) {
      setError('SEARCH_ERROR');
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (newQuery: string) => {
    setSearchParams({ q: newQuery, filter });
  };

  const handleUrlSubmit = (input: string) => {
    const videoId = extractVideoId(input);
    if (videoId) {
      navigate(`/watch/${videoId}`);
    } else {
      handleSearch(input);
    }
  };

  const handleFilterChange = (newFilter: FilterMode) => {
    setSearchParams({ q: query, filter: newFilter });
  };

  return (
    <div className="min-h-[calc(100vh-4rem)]">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Search bar */}
        <div className="mb-8">
          <SearchBar
            onSearch={handleSearch}
            onUrlSubmit={handleUrlSubmit}
            initialValue={query}
            placeholder="Buscar videos..."
          />
        </div>

        {/* Filter pills */}
        {query && (
          <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
            {(['STRICT', 'SAFE', 'EDUCATIONAL', 'GENERAL'] as FilterMode[]).map((mode) => (
              <button
                key={mode}
                onClick={() => handleFilterChange(mode)}
                className={`px-3 py-1.5 text-xs font-medium rounded-full border transition-all whitespace-nowrap ${
                  filter === mode
                    ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-300'
                    : 'bg-[#12121f] border-[#1e1e35] text-slate-400 hover:text-slate-300'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        )}

        {/* Loading */}
        {loading && (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mb-4" />
            <p className="text-sm text-slate-500">Buscando videos...</p>
            {currentServer && (
              <p className="text-xs text-slate-600 mt-1">Conectando con servidor...</p>
            )}
          </div>
        )}

        {/* Search error */}
        {error === 'SEARCH_ERROR' && !loading && (
          <div className="flex items-center justify-center py-20">
            <div className="text-center max-w-md">
              <WifiOff className="w-10 h-10 text-red-400 mx-auto mb-3" />
              <h3 className="text-white font-medium mb-2">Error de conexión</h3>
              <p className="text-slate-400 text-sm mb-4">
                No se pudo conectar con los servidores. Intenta de nuevo en unos momentos.
              </p>
              <button
                onClick={() => performSearch(query, filter)}
                className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm rounded-lg transition-colors"
              >
                <Wifi className="w-4 h-4" />
                Reintentar
              </button>
            </div>
          </div>
        )}

        {/* Results */}
        {!loading && !error && results.length > 0 && (
          <div>
            <p className="text-sm text-slate-500 mb-4">
              {results.length} resultado{results.length !== 1 ? 's' : ''} para "{query}"
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {results.map((video) => (
                <VideoCard key={video.id} video={video} />
              ))}
            </div>
          </div>
        )}

        {/* Empty state */}
        {!loading && !error && query && results.length === 0 && (
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <Search className="w-10 h-10 text-slate-600 mx-auto mb-3" />
              <p className="text-slate-400">No se encontraron resultados para "{query}"</p>
              <p className="text-sm text-slate-500 mt-2">Intenta con otros términos o revisa el filtro seleccionado</p>
            </div>
          </div>
        )}

        {/* Initial state */}
        {!query && (
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <Search className="w-10 h-10 text-slate-600 mx-auto mb-3" />
              <p className="text-slate-400">Escribe algo para buscar videos</p>
              <p className="text-sm text-slate-500 mt-2">
                También puedes pegar una URL de YouTube directamente
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

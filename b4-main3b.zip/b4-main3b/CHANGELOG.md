# Changelog

Todos los cambios notables de este proyecto serán documentados en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es-ES/1.0.0/),
y este proyecto sigue [Semantic Versioning](https://semver.org/lang/es/).

## [Unreleased]

### Planned
- V2: URL directa mejorada + validación avanzada
- V3: SafeSearch + filtros avanzados
- V4: Blocklist + reportes mejorados
- V5: Cuentas + historial + favoritos
- V6: Modo Education
- V7: Moderación avanzada
- V8: Admin Panel
- V9: Múltiples servidores + fallback mejorado
- V10: Extensión de navegador
- V11: PWA + móvil
- V12: Optimización avanzada

## [1.0.0] - 2024

### Added
- Interfaz principal con diseño dark mode
- Buscador de videos con Piped API (sin API key requerida)
- Reproductor de video limpio y minimalista
- Detección automática de URLs de YouTube
- Validación de video IDs
- Sistema de filtros (STRICT, SAFE, EDUCATIONAL, GENERAL)
- Blocklist para contenido bloqueado
- Sistema de reportes con múltiples motivos
- Múltiples servidores con fallback automático
- Diseño responsive (mobile, tablet, desktop)
- Arquitectura modular preparada para expansiones
- Página de inicio con buscador y campo URL
- Página de búsqueda con resultados en grid
- Página de reproducción con información del video
- Sistema de navegación con React Router
- Componentes reutilizables (Header, SearchBar, VideoCard, VideoPlayer)
- Tipos TypeScript completos
- Utilidades para manejo de URLs de YouTube
- Servicio de búsqueda con rotación de servidores
- README.md con documentación completa
- Guía de contribución (CONTRIBUTING.md)
- Licencia MIT

### Technical Details
- React 18 con TypeScript
- Vite como build tool
- Tailwind CSS 4 para estilos
- React Router para navegación
- Lucide React para iconos
- Piped API para búsqueda de videos
- 4 servidores de respaldo configurados
- Sistema de fallback automático
- localStorage para blocklist y reportes

### Security
- No se recopilan datos personales innecesarios
- No se exponen claves privadas en el frontend
- Reportes y blocklist almacenados localmente
- Uso de APIs oficiales y compatibles

---

## Formato de Entries

### Added
- Nuevas funcionalidades

### Changed
- Cambios en funcionalidades existentes

### Deprecated
- Funcionalidades que serán eliminadas

### Removed
- Funcionalidades eliminadas

### Fixed
- Correcciones de bugs

### Security
- Cambios relacionados con seguridad

# 📤 Instrucciones para Subir ibeTube a GitHub

## Paso 1: Crear Repositorio en GitHub

1. Ve a https://github.com/new
2. Nombre del repositorio: `ibetube` (o el que prefieras)
3. Descripción: `Plataforma de visualización de videos limpia, segura y sin distracciones`
4. **NO** inicializar con README (ya lo tenemos)
5. Haz clic en "Create repository"

## Paso 2: Inicializar Git Localmente

Abre una terminal en la carpeta de tu proyecto y ejecuta:

```bash
# Inicializar git
git init

# Agregar todos los archivos
git add .

# Primer commit
git commit -m "feat: ibeTube v1.0 - Video viewer limpio y seguro"
```

## Paso 3: Conectar con GitHub

```bash
# Renombrar la rama principal a 'main'
git branch -M main

# Agregar el repositorio remoto (REEMPLAZA TU-USUARIO con tu usuario de GitHub)
git remote add origin https://github.com/TU-USUARIO/ibetube.git

# Subir el código
git push -u origin main
```

## Paso 4: Verificar

1. Ve a tu repositorio en GitHub: `https://github.com/TU-USUARIO/ibetube`
2. Recarga la página
3. Deberías ver todos los archivos y el README

## 📁 Archivos Incluidos

### Documentación
- ✅ README.md - Documentación principal
- ✅ CONTRIBUTING.md - Guía de contribución
- ✅ CHANGELOG.md - Historial de cambios
- ✅ LICENSE - Licencia MIT

### Configuración
- ✅ .gitignore - Archivos ignorados por Git
- ✅ package.json - Dependencias del proyecto
- ✅ tsconfig.json - Configuración TypeScript
- ✅ vite.config.js - Configuración Vite

### Código Fuente
- ✅ index.html - HTML principal
- ✅ src/App.tsx - Router principal
- ✅ src/main.tsx - Entry point
- ✅ src/index.css - Estilos globales

### Componentes
- ✅ src/components/Header.tsx
- ✅ src/components/SearchBar.tsx
- ✅ src/components/VideoCard.tsx
- ✅ src/components/VideoPlayer.tsx

### Páginas
- ✅ src/pages/Home.tsx
- ✅ src/pages/Watch.tsx
- ✅ src/pages/Search.tsx

### Servicios y Utilidades
- ✅ src/services/search.ts - Servicio de búsqueda (Piped API)
- ✅ src/utils/youtube.ts - Utilidades YouTube
- ✅ src/types/index.ts - Tipos TypeScript

### Assets
- ✅ public/favicon.svg - Icono de la aplicación

## 🚀 Próximos Pasos

### Opcional: Configurar GitHub Pages

Si quieres desplegar la aplicación en GitHub Pages:

1. Instala gh-pages:
```bash
npm install --save-dev gh-pages
```

2. Agrega en package.json (scripts):
```json
"predeploy": "npm run build",
"deploy": "gh-pages -d dist"
```

3. Agrega en vite.config.js:
```js
export default defineConfig({
  base: '/ibetube/',
  // ... resto de configuración
})
```

4. Despliega:
```bash
npm run deploy
```

5. En GitHub, ve a Settings > Pages y selecciona la rama `gh-pages`

### Opcional: Configurar Netlify/Vercel

Para despliegue automático:

**Netlify:**
1. Conecta tu repositorio en netlify.com
2. Build command: `npm run build`
3. Publish directory: `dist`

**Vercel:**
1. Conecta tu repositorio en vercel.com
2. Framework preset: Vite
3. Deploy

## 📝 Notas Importantes

- El archivo `.gitignore` ya está configurado para excluir `node_modules/` y `dist/`
- No subas el archivo `package-lock.json` si prefieres (está en .gitignore)
- Los datos de localStorage (blocklist, reportes) son locales y no se suben
- No hay claves API expuestas en el código

## 🆘 Solución de Problemas

### Error: "fatal: remote origin already exists"
```bash
git remote remove origin
git remote add origin https://github.com/TU-USUARIO/ibetube.git
```

### Error: "Updates were rejected because the remote contains work"
```bash
git pull origin main --rebase
git push -u origin main
```

### Error: "Permission denied (publickey)"
Usa HTTPS en lugar de SSH:
```bash
git remote set-url origin https://github.com/TU-USUARIO/ibetube.git
```

---

¡Listo! Tu proyecto ibeTube ahora está en GitHub 🎉
